import Layout from "@app/components/layout";
import React from "react";

export default () => (
  <Layout>
    HAHAHA
  </Layout>
)